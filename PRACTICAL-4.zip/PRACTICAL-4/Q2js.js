let rand=Math.floor(Math.random()*5)+1;
let i=0
let flag=0
alert("Welcome");
while(i<5){
    let ipt=prompt("ENter the number")
    if(ipt==rand){
        alert("GOOD work");
        flag=1;
        break;
    }
    i++;
}
if(flag==0){
    alert("Not Matched");
}